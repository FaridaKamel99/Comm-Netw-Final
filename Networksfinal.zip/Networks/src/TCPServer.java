import java.io.*; 
import java.net.*; 

public class TCPServer {

	  public static void main(String argv[]) throws Exception 
	    { 
	      String clientSentence; 
	      String capitalizedSentence; 

	      ServerSocket welcomeSocket = new ServerSocket(4321); 
	  
	      while(true) { 
	    	  
	            Socket connectionSocket = welcomeSocket.accept(); 

	           BufferedReader inFromClient = 
	              new BufferedReader(new
	              InputStreamReader(connectionSocket.getInputStream())); 
	           clientSentence = inFromClient.readLine();
		        System.out.println("Client Says: "+clientSentence);

	           if(clientSentence.equals("connect")) {
	        	   System.out.println("Client Connected");
	        	   int i=1;
	        	   while(true) {
	    	           clientSentence = inFromClient.readLine();
	    	           
	        		   if(!clientSentence.equals("bye")) {
	        			   
	        		   
	        		   
	       		        System.out.println("Client Says: "+clientSentence);
	        	   
	           
	           DataOutputStream  outToClient = 
	                   new DataOutputStream(connectionSocket.getOutputStream()); 

	                 
	     	        
	           BufferedReader messageToClient=new BufferedReader(new
	              InputStreamReader(System.in));
	                 capitalizedSentence = messageToClient.readLine();

	                 outToClient.writeBytes(capitalizedSentence+'\n'); 
	              }
	        		   else{
	        			   connectionSocket.close();
	        			   System.out.println("Connection Closed");
	        			   break;
	        		   }
	        			  i++; }}
	        		   }
	          } 
	      


}
	    
